import Swiper from './swiper.vue'
import SwiperItem from './swiperitem.vue'

export {
  Swiper, SwiperItem
}
