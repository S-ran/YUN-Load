<template>
    <div>
        <nav-bar class="nav-bar">
            <div slot="left" class="font icon-liebiao"></div>
            <div slot="center">关注</div>
        </nav-bar> 
    </div>
</template>

<script>
import NavBar from '@/components/common/NavBar'
    export default {
        components:{
            NavBar  
        }
    }
</script>

<style lang="scss" scoped>

</style>